#!/usr/bin/env python

import numpy as np
import CovMap_from_Mat as cfm
import matplotlib.pyplot as pp; pp.ion()

prefix="pLAA_toy"
sysconfigfile = "sysconfig_"+prefix+".npz"
locals().update(np.load(sysconfigfile)) # easier than: shnxsub = npfile["shnxsub"], etc.
MapMask = np.tile(cfm.MapMask_from_validsubs(validsubs,shnxsub),
            [2*nwfs,2*nwfs])

def CovMap_dT(dT):
    return cfm.CovMap_from_Cn2 (MapMask,telDiam,zenith,
            shnxsub,r0,Cn2,l0,alt,nwfs,gspos,gsalt,
            timedelay=dT*ittime,
            windspeed=windspeed,
            winddir=winddir)

def Cmm_dT(dT): 
    cmm = cfm.Mat_from_CovMap(CovMap_dT(dT),nwfs,validsubs,shnxsub)
    cmm = np.tril(cmm)+np.tril(cmm).T - np.diag(cmm.diagonal())
    return cmm
    """
    # these all return approximately the same thing:
    cmm1 = cfm.Mat_from_CovMap(CovMap_dT(dT),nwfs,validsubs,shnxsub)
    cmm1 = np.tril(cmm1)+np.tril(cmm1).T - np.diag(cmm1.diagonal())
    cmm2 = cfm.CMM_from_npz(prefix=prefix,dT=dT)
    cmm3 = cfm.CMM_from_Cn2(telDiam,zenith,shnxsub,xx,yy,
                            r0,Cn2,l0,alt,nwfs,gspos,gsalt,
                            timedelay=dT*ittime,
                            windspeed=windspeed,winddir=winddir)
    """

if __name__=="__main__":
    for dT in [0,1,100,500]:
        if 1==0: # Do CovMap (else Cmm)
            CovMap = CovMap_dT(dT)
            pp.matshow(CovMap)
            pp.title(f"dT = {dT:d}")
        else: # Do Cmm
            Cmm = Cmm_dT(dT)
            pp.matshow(Cmm)
            pp.title(f"dT = {dT:d}, sum = {Cmm.sum():f}")
